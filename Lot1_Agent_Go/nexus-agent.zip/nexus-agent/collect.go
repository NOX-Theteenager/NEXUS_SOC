package main

import (
	"bufio"
	"crypto/sha256"
	"encoding/csv"
	"encoding/hex"
	"fmt"
	"io"
	"io/fs"
	"net"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
)

// --------------------------------------------------------------------------- //
// Processus actifs
// --------------------------------------------------------------------------- //
func collectProcesses(cache map[string]string) []Event {
	if runtime.GOOS == "windows" {
		return collectProcessesWindows()
	}
	return collectProcessesLinux(cache)
}

func sha256File(path string) string {
	f, err := os.Open(path)
	if err != nil {
		return ""
	}
	defer f.Close()
	h := sha256.New()
	if _, err := io.Copy(h, f); err != nil {
		return ""
	}
	return hex.EncodeToString(h.Sum(nil))
}

func collectProcessesLinux(cache map[string]string) []Event {
	var events []Event
	entries, err := os.ReadDir("/proc")
	if err != nil {
		return events
	}
	newHashes := 0
	for _, e := range entries {
		if !e.IsDir() {
			continue
		}
		pid := e.Name()
		if _, err := strconv.Atoi(pid); err != nil {
			continue
		}
		comm, _ := os.ReadFile("/proc/" + pid + "/comm")
		name := strings.TrimSpace(string(comm))
		exe, _ := os.Readlink("/proc/" + pid + "/exe")
		sha := ""
		if exe != "" {
			if h, ok := cache[exe]; ok {
				sha = h
			} else if newHashes < 100 { // borne le coût CPU par cycle
				sha = sha256File(exe)
				if sha != "" {
					cache[exe] = sha
					newHashes++
				}
			}
		}
		events = append(events, Event{Kind: "process", Time: nowISO(), Data: map[string]any{
			"pid": pid, "name": name, "exe": exe, "sha256": sha,
		}})
	}
	return events
}

func collectProcessesWindows() []Event {
	var events []Event
	out, err := exec.Command("tasklist", "/fo", "csv", "/nh").Output()
	if err != nil {
		return events
	}
	r := csv.NewReader(strings.NewReader(string(out)))
	rows, _ := r.ReadAll()
	for _, row := range rows {
		if len(row) < 2 {
			continue
		}
		events = append(events, Event{Kind: "process", Time: nowISO(), Data: map[string]any{
			"name": row[0], "pid": row[1],
		}})
	}
	return events
}

// --------------------------------------------------------------------------- //
// Connexions réseau
// --------------------------------------------------------------------------- //
func collectConnections() []Event {
	if runtime.GOOS == "windows" {
		return collectConnectionsWindows()
	}
	var events []Event
	events = append(events, parseProcNet("/proc/net/tcp", "tcp")...)
	events = append(events, parseProcNet("/proc/net/tcp6", "tcp6")...)
	return events
}

var tcpStates = map[string]string{
	"01": "ESTABLISHED", "02": "SYN_SENT", "03": "SYN_RECV", "04": "FIN_WAIT1",
	"05": "FIN_WAIT2", "06": "TIME_WAIT", "07": "CLOSE", "08": "CLOSE_WAIT",
	"09": "LAST_ACK", "0A": "LISTEN", "0B": "CLOSING",
}

func parseProcNet(path, proto string) []Event {
	f, err := os.Open(path)
	if err != nil {
		return nil
	}
	defer f.Close()
	var events []Event
	sc := bufio.NewScanner(f)
	sc.Scan() // en-tête
	for sc.Scan() {
		fields := strings.Fields(sc.Text())
		if len(fields) < 4 {
			continue
		}
		state := tcpStates[strings.ToUpper(fields[3])]
		if state == "" {
			state = fields[3]
		}
		events = append(events, Event{Kind: "connection", Time: nowISO(), Data: map[string]any{
			"proto": proto, "local": hexToAddr(fields[1]),
			"remote": hexToAddr(fields[2]), "state": state,
		}})
	}
	return events
}

// convertit l'adresse hexadécimale de /proc/net/tcp en IP:port lisible
func hexToAddr(s string) string {
	parts := strings.Split(s, ":")
	if len(parts) != 2 {
		return s
	}
	ipHex, portHex := parts[0], parts[1]
	port, _ := strconv.ParseInt(portHex, 16, 32)
	b, err := hex.DecodeString(ipHex)
	if err != nil {
		return s
	}
	if len(b) == 4 { // IPv4 (octets en little-endian)
		ip := net.IPv4(b[3], b[2], b[1], b[0])
		return fmt.Sprintf("%s:%d", ip.String(), port)
	}
	if len(b) == 16 { // IPv6 (4 mots 32 bits little-endian)
		ip := make(net.IP, 16)
		for i := 0; i < 16; i += 4 {
			ip[i], ip[i+1], ip[i+2], ip[i+3] = b[i+3], b[i+2], b[i+1], b[i]
		}
		return fmt.Sprintf("[%s]:%d", ip.String(), port)
	}
	return s
}

func collectConnectionsWindows() []Event {
	var events []Event
	out, err := exec.Command("netstat", "-ano", "-p", "tcp").Output()
	if err != nil {
		return events
	}
	for _, line := range strings.Split(string(out), "\n") {
		f := strings.Fields(line)
		if len(f) < 4 || !strings.HasPrefix(strings.ToUpper(f[0]), "TCP") {
			continue
		}
		events = append(events, Event{Kind: "connection", Time: nowISO(), Data: map[string]any{
			"proto": "tcp", "local": f[1], "remote": f[2], "state": f[3],
		}})
	}
	return events
}

// --------------------------------------------------------------------------- //
// Modifications de fichiers (surveillance par scrutation des dates de modif)
// --------------------------------------------------------------------------- //
type fileWatcher struct{ seen map[string]int64 }

func newFileWatcher() *fileWatcher { return &fileWatcher{seen: map[string]int64{}} }

func (w *fileWatcher) scan(paths []string) []Event {
	var events []Event
	for _, p := range paths {
		filepath.WalkDir(p, func(path string, d fs.DirEntry, err error) error {
			if err != nil || d.IsDir() {
				return nil
			}
			info, err := d.Info()
			if err != nil {
				return nil
			}
			mt := info.ModTime().Unix()
			prev, known := w.seen[path]
			w.seen[path] = mt
			if known && mt != prev { // fichier modifié depuis le dernier scan
				events = append(events, Event{Kind: "file_change", Time: nowISO(), Data: map[string]any{
					"path": path, "size": info.Size(),
				}})
			}
			return nil
		})
	}
	return events
}

// --------------------------------------------------------------------------- //
// État système
// --------------------------------------------------------------------------- //
func collectSystem() Event {
	host, _ := os.Hostname()
	data := map[string]any{"hostname": host, "os": runtime.GOOS, "arch": runtime.GOARCH}
	if runtime.GOOS == "linux" {
		if b, err := os.ReadFile("/proc/uptime"); err == nil {
			if fields := strings.Fields(string(b)); len(fields) > 0 {
				data["uptime_s"] = fields[0]
			}
		}
		if b, err := os.ReadFile("/proc/loadavg"); err == nil {
			data["loadavg"] = strings.Fields(string(b))
		}
	}
	return Event{Kind: "system", Time: nowISO(), Data: data}
}
