// NEXUS SOC — Agent universel léger (Lot 1)
//
// Source de télémétrie : collecte l'activité du poste (processus, connexions réseau,
// modifications de fichiers, état système) et l'envoie en EGRESS-ONLY (HTTPS sortant)
// vers la passerelle d'ingestion de NEXUS SOC, qui la produit dans Kafka.
//
// Caractéristiques :
//   • Pur stdlib Go (aucune dépendance externe → binaire léger, surface d'attaque minimale)
//   • Multiplateforme (Linux + Windows)
//   • Store-and-forward : buffer local persistant, rejeu après coupure réseau/électrique
//   • Envoi compressé (gzip) + signé (HMAC) — sobriété en bande passante, authenticité
//
// Auteur : NGUETSA Junior Stéphane Céleste — Projet NEXUS SOC
package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"log"
	"os"
	"os/signal"
	"runtime"
	"syscall"
	"time"
)

type Event struct {
	Kind string         `json:"kind"`
	Time string         `json:"time"`
	Data map[string]any `json:"data"`
}

type Batch struct {
	AgentID  string  `json:"agent_id"`
	TenantID string  `json:"tenant_id"`
	Host     string  `json:"host"`
	OS       string  `json:"os"`
	SentAt   string  `json:"sent_at"`
	Events   []Event `json:"events"`
}

type Config struct {
	ServerURL     string   `json:"server_url"`
	EnrollToken   string   `json:"enroll_token"`
	HMACKey       string   `json:"hmac_key"`
	AgentID       string   `json:"agent_id"`
	TenantID      string   `json:"tenant_id"`
	IntervalSec   int      `json:"interval_sec"`
	WatchPaths    []string `json:"watch_paths"`
	SpoolDir      string   `json:"spool_dir"`
	MaxSpoolFiles int      `json:"max_spool_files"`
}

func loadConfig(path string) (*Config, error) {
	c := &Config{IntervalSec: 30, SpoolDir: "./spool", MaxSpoolFiles: 500}
	b, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	if err := json.Unmarshal(b, c); err != nil {
		return nil, err
	}
	if c.IntervalSec <= 0 {
		c.IntervalSec = 30
	}
	if c.SpoolDir == "" {
		c.SpoolDir = "./spool"
	}
	if c.MaxSpoolFiles <= 0 {
		c.MaxSpoolFiles = 500
	}
	return c, nil
}

func nowISO() string { return time.Now().UTC().Format(time.RFC3339) }

// collecte un lot complet de télémétrie
func collectBatch(cfg *Config, hashCache map[string]string, fw *fileWatcher) Batch {
	host, _ := os.Hostname()
	var events []Event
	events = append(events, collectProcesses(hashCache)...)
	events = append(events, collectConnections()...)
	events = append(events, fw.scan(cfg.WatchPaths)...)
	events = append(events, collectSystem())
	return Batch{
		AgentID: cfg.AgentID, TenantID: cfg.TenantID, Host: host,
		OS: runtime.GOOS, SentAt: nowISO(), Events: events,
	}
}

func main() {
	cfgPath := flag.String("config", "config.json", "chemin du fichier de configuration")
	once := flag.Bool("once", false, "collecte un seul lot, l'affiche, puis quitte")
	flag.Parse()

	cfg, err := loadConfig(*cfgPath)
	if err != nil {
		log.Fatalf("configuration : %v", err)
	}

	buf := NewBuffer(cfg.SpoolDir, cfg.MaxSpoolFiles)
	sender := NewSender(cfg.ServerURL, cfg.EnrollToken, cfg.HMACKey)
	hashCache := map[string]string{}
	fw := newFileWatcher()

	collectAndQueue := func() {
		batch := collectBatch(cfg, hashCache, fw)
		raw, _ := json.Marshal(batch)
		if *once {
			pretty, _ := json.MarshalIndent(batch, "", "  ")
			fmt.Println(string(pretty))
		}
		if err := buf.Enqueue(raw); err != nil {
			log.Printf("buffer : %v", err)
		}
		log.Printf("lot collecté : %d événements (en file : %d)", len(batch.Events), buf.Count())
	}

	flush := func() {
		if cfg.ServerURL == "" {
			return // pas de serveur configuré (mode hors-ligne / test)
		}
		for _, f := range buf.Pending() {
			raw, err := buf.Read(f)
			if err != nil {
				buf.Remove(f)
				continue
			}
			if err := sender.Send(raw); err != nil {
				log.Printf("envoi différé (serveur injoignable) : %v", err)
				return // on garde le lot pour rejeu ultérieur (store-and-forward)
			}
			buf.Remove(f)
		}
	}

	// Mode --once : un seul cycle puis sortie
	if *once {
		collectAndQueue()
		flush()
		return
	}

	log.Printf("NEXUS SOC — agent démarré (intervalle %ds, egress → %s)", cfg.IntervalSec, cfg.ServerURL)
	ticker := time.NewTicker(time.Duration(cfg.IntervalSec) * time.Second)
	defer ticker.Stop()

	stop := make(chan os.Signal, 1)
	signal.Notify(stop, os.Interrupt, syscall.SIGTERM)

	collectAndQueue()
	flush()
	for {
		select {
		case <-ticker.C:
			collectAndQueue()
			flush()
		case <-stop:
			log.Println("arrêt demandé — vidage du buffer puis sortie")
			flush()
			return
		}
	}
}
