module nexussoc/agent

go 1.22
