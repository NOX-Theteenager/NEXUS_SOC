package main

import (
	"bytes"
	"compress/gzip"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"io"
	"net/http"
	"time"
)

// Sender envoie un lot vers la passerelle d'ingestion en EGRESS-ONLY :
//   • HTTPS sortant uniquement (fonctionne derrière n'importe quel pare-feu) ;
//   • compression gzip (sobriété en bande passante — contexte de connectivité limitée) ;
//   • signature HMAC-SHA256 du corps (authenticité, intégrité) ;
//   • jeton d'enrôlement en en-tête Authorization.
type Sender struct {
	url    string
	token  string
	key    []byte
	client *http.Client
}

func NewSender(url, token, hmacKey string) *Sender {
	return &Sender{
		url: url, token: token, key: []byte(hmacKey),
		client: &http.Client{Timeout: 20 * time.Second},
	}
}

func (s *Sender) Send(raw []byte) error {
	// compression gzip
	var buf bytes.Buffer
	gz := gzip.NewWriter(&buf)
	if _, err := gz.Write(raw); err != nil {
		return err
	}
	if err := gz.Close(); err != nil {
		return err
	}
	body := buf.Bytes()

	// signature HMAC-SHA256 du corps compressé
	mac := hmac.New(sha256.New, s.key)
	mac.Write(body)
	sig := hex.EncodeToString(mac.Sum(nil))

	req, err := http.NewRequest(http.MethodPost, s.url, bytes.NewReader(body))
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Content-Encoding", "gzip")
	req.Header.Set("Authorization", "Bearer "+s.token)
	req.Header.Set("X-Signature", sig)

	resp, err := s.client.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	io.Copy(io.Discard, resp.Body)
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return fmt.Errorf("réponse serveur %d", resp.StatusCode)
	}
	return nil
}
