package main

import (
	"fmt"
	"math/rand"
	"os"
	"path/filepath"
	"sort"
	"time"
)

// Buffer persiste les lots sur disque (un fichier JSON par lot).
// Les lots survivent à un redémarrage ou à une coupure de courant ; ils sont
// rejoués lorsque le serveur redevient joignable. La taille est bornée pour
// éviter de remplir le disque (les plus anciens sont supprimés au-delà du seuil).
type Buffer struct {
	dir string
	max int
}

func NewBuffer(dir string, max int) *Buffer {
	_ = os.MkdirAll(dir, 0o755)
	return &Buffer{dir: dir, max: max}
}

func (b *Buffer) Enqueue(raw []byte) error {
	name := fmt.Sprintf("%d-%04d.json", time.Now().UnixNano(), rand.Intn(10000))
	tmp := filepath.Join(b.dir, name+".tmp")
	final := filepath.Join(b.dir, name)
	if err := os.WriteFile(tmp, raw, 0o644); err != nil {
		return err
	}
	if err := os.Rename(tmp, final); err != nil { // écriture atomique
		return err
	}
	b.enforceCap()
	return nil
}

func (b *Buffer) Pending() []string {
	entries, err := os.ReadDir(b.dir)
	if err != nil {
		return nil
	}
	var files []string
	for _, e := range entries {
		if !e.IsDir() && filepath.Ext(e.Name()) == ".json" {
			files = append(files, filepath.Join(b.dir, e.Name()))
		}
	}
	sort.Strings(files) // ordre chronologique (préfixe = horodatage)
	return files
}

func (b *Buffer) Count() int { return len(b.Pending()) }

func (b *Buffer) Read(path string) ([]byte, error) { return os.ReadFile(path) }

func (b *Buffer) Remove(path string) { _ = os.Remove(path) }

func (b *Buffer) enforceCap() {
	files := b.Pending()
	for len(files) > b.max {
		_ = os.Remove(files[0]) // supprime le plus ancien
		files = files[1:]
	}
}
