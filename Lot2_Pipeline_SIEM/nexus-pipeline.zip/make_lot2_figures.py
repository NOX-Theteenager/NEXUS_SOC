# -*- coding: utf-8 -*-
"""Figures du Lot 2 : reconstitution de la chaîne + couverture MITRE."""
import json
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

NAVY, BLUE, TEAL, RED, AMBER, GREY = "#0B2545", "#1C6DD0", "#1B998B", "#C1432E", "#B7791F", "#64748B"
LGREY, MGREY, TXT, WHITE = "#EEF3F8", "#CBD5E1", "#1E293B", "#FFFFFF"
plt.rcParams["font.family"] = "DejaVu Sans"

OUT = "/home/claude/nexus/pipeline/out_lot2"

# ============================================================
# 1. Chronologie de la chaîne reconstituée (incident de démonstration)
# ============================================================
inc = json.load(open(f"{OUT}/correlated_incidents.json"))[0]
steps = inc["chaine"]
TAC_COLOR = {"Initial Access": BLUE, "Execution": TEAL, "Collection": AMBER,
             "Command and Control": RED, "Impact": "#7B1E1E", "Persistence": "#5B21B6"}

fig, ax = plt.subplots(figsize=(12.6, 5.3))
ax.set_xlim(-0.5, len(steps) - 0.5); ax.set_ylim(0, 10); ax.axis("off")
ax.set_title(f"NEXUS SOC — Chaîne d'attaque reconstituée par le SIEM\n"
             f"hôte {inc['entity']} · type « {inc['type']} » · risque {inc['risque']}/100"
             + ("   (activité hors heures)" if inc["activite_hors_heures"] else ""),
             fontsize=12.5, weight="bold", color=NAVY, pad=12)

# ligne de temps
ax.plot([0, len(steps) - 1], [5, 5], color=MGREY, lw=2.2, zorder=1)
for i, s in enumerate(steps):
    c = TAC_COLOR.get(s["tactique"], NAVY)
    ax.scatter([i], [5], s=160, color=c, zorder=3, edgecolor="white", linewidth=2)
    # bloc tactique sous le point
    ax.add_patch(FancyBboxPatch((i - 0.42, 1.7), 0.84, 1.6, boxstyle="round,pad=0.002,rounding_size=0.04",
                 facecolor=c, edgecolor=c))
    ax.text(i, 2.5, s["tactique"], ha="center", va="center", color="white",
            fontsize=8.4, weight="bold")
    # technique + détail au-dessus
    ax.text(i, 6.2, s["heure"], ha="center", fontsize=8.5, color=NAVY, weight="bold")
    ax.text(i, 7.0, s["technique"].split(" ")[0], ha="center", fontsize=8, color=NAVY)
    detail = s["detail"]
    if len(detail) > 30:
        detail = detail[:28] + "…"
    ax.text(i, 7.8, detail, ha="center", fontsize=7.8, color=GREY, style="italic")

# annotation incident global
ax.text(len(steps) / 2 - 0.5, 0.3,
        "→ Alerte unique transmise au SOAR (au lieu de 6 alertes isolées)",
        ha="center", fontsize=9, color=RED, weight="bold")
plt.tight_layout()
fig.savefig(f"{OUT}/chain_reconstruction.png", dpi=190, bbox_inches="tight", facecolor=WHITE)
plt.close(fig)

# ============================================================
# 2. Matrice de couverture MITRE (tactiques × techniques détectées par le moteur)
# ============================================================
RULES = [
    ("Initial Access",       "T1204", "User Execution: Malicious File", "file_change Downloads + ext exécutable"),
    ("Execution",            "T1059", "Command and Scripting Interpreter", "process cmd/powershell/wscript/…"),
    ("Execution",            "T1059", "Exécution depuis répertoire temporaire", "process exe dans /tmp"),
    ("Collection",           "T1005", "Data from Local System", "file_change sur dossier sensible"),
    ("Command and Control",  "T1071", "Application Layer Protocol", "connexion vers port C2 connu ou IP TI"),
    ("Impact",               "T1486", "Data Encrypted for Impact", "> 20 file_change en 5 min"),
]
tactics = ["Initial Access", "Execution", "Collection", "Command and Control", "Impact"]
fig, ax = plt.subplots(figsize=(12, 4.2))
ax.set_xlim(0, 100); ax.set_ylim(0, len(tactics) * 1.3); ax.axis("off")

# bandes par tactique
for i, t in enumerate(tactics):
    y = (len(tactics) - 1 - i) * 1.3
    c = TAC_COLOR.get(t, NAVY)
    ax.add_patch(FancyBboxPatch((1, y + 0.05), 18, 1.1, boxstyle="round,pad=0.002,rounding_size=0.04",
                 facecolor=c, edgecolor=c))
    ax.text(10, y + 0.6, t, ha="center", va="center", color="white", fontsize=9.5, weight="bold")
    rules_t = [r for r in RULES if r[0] == t]
    x = 20
    for r in rules_t:
        w = 38
        ax.add_patch(FancyBboxPatch((x, y + 0.1), w, 1.0, boxstyle="round,pad=0.002,rounding_size=0.03",
                     facecolor=WHITE, edgecolor=c, linewidth=1.5))
        ax.text(x + 1.2, y + 0.78, f"{r[1]} — {r[2]}", fontsize=8.4, color=NAVY, weight="bold")
        ax.text(x + 1.2, y + 0.30, r[3], fontsize=7.6, color=GREY, style="italic")
        x += w + 1.5

ax.set_title("NEXUS SOC — Couverture MITRE ATT&CK du moteur de corrélation (Lot 2)",
             fontsize=12.5, weight="bold", color=NAVY, pad=10)
ax.text(50, -0.5, "La chaîne est levée quand ≥ 3 tactiques (ou Exécution + C2, ou Impact) sont observées sur le même hôte dans une fenêtre de 30 min.",
        ha="center", fontsize=8.4, color=GREY, style="italic")
plt.tight_layout()
fig.savefig(f"{OUT}/mitre_coverage.png", dpi=190, bbox_inches="tight", facecolor=WHITE)
plt.close(fig)

print("Figures générées :", "chain_reconstruction.png", "mitre_coverage.png")
