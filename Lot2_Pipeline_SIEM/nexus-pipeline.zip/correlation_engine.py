#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NEXUS SOC — Moteur de corrélation SIEM (Lot 2)
==============================================
Ingère la télémétrie normalisée, détecte des techniques MITRE ATT&CK via des règles,
et RECONSTITUE les chaînes d'attaque multi-étapes : une seule alerte corrélée et enrichie
plutôt qu'une multitude d'événements isolés. L'incident produit alimente le SOAR.

Usage : python correlation_engine.py [--out ./out_lot2]
"""
import argparse, json, os
from collections import defaultdict
from datetime import datetime, timedelta

from telemetry_gen import generate

# ---- Renseignement / listes de détection ----
SUSPICIOUS_PROCS = {"cmd.exe", "powershell.exe", "powershell", "wscript.exe",
                    "cscript.exe", "nc", "ncat", "mshta.exe", "rundll32.exe"}
C2_PORTS = {"4444", "6667", "1337", "9001", "31337", "5555"}
TI_IPS = {"185.220.101.45"}                      # threat intel (ex. nœud malveillant connu)
SENSITIVE = ("/etc/shadow", "/etc/passwd", "/etc/sudoers", "finance", "budget", "contribuable")
DOWNLOAD_EXT = (".exe", ".scr", ".js", ".bat", ".vbs")

WINDOW = timedelta(minutes=30)                   # fenêtre de corrélation
MASS_FILE_THRESHOLD = 20                          # fichiers modifiés → impact (rançongiciel)


def detect(ev):
    """Renvoie (tactique, technique_id, technique_nom, détail) ou None."""
    d = ev.get("data", {})
    k = ev["kind"]
    if k == "process":
        name = (d.get("name") or "").lower()
        exe = d.get("exe") or ""
        if name in SUSPICIOUS_PROCS:
            return ("Execution", "T1059", "Command and Scripting Interpreter", f"processus {name}")
        if exe.startswith("/tmp") or (exe and "temp" in exe.lower()):
            return ("Execution", "T1059", "Exécution depuis un répertoire temporaire", exe)
    elif k == "connection":
        remote = d.get("remote", ":")
        ip = remote.rsplit(":", 1)[0].strip("[]")
        port = remote.rsplit(":", 1)[-1]
        if port in C2_PORTS or ip in TI_IPS:
            return ("Command and Control", "T1071", "Application Layer Protocol", f"connexion vers {remote}")
    elif k == "file_change":
        path = (d.get("path") or "").lower()
        if any(s in path for s in SENSITIVE):
            return ("Collection", "T1005", "Data from Local System", d.get("path"))
        if "download" in path and path.endswith(DOWNLOAD_EXT):
            return ("Initial Access", "T1204", "User Execution: Malicious File", d.get("path"))
    return None


def detect_mass_file_change(events):
    """Détecte une modification massive de fichiers (rançongiciel) sur une fenêtre."""
    files = sorted([e for e in events if e["kind"] == "file_change"], key=lambda e: e["time"])
    for i, e in enumerate(files):
        t0 = datetime.fromisoformat(e["time"])
        window = [f for f in files if 0 <= (datetime.fromisoformat(f["time"]) - t0).total_seconds() <= 300]
        if len(window) >= MASS_FILE_THRESHOLD:
            ts_seuil = window[MASS_FILE_THRESHOLD - 1]["time"]   # moment où le seuil est franchi
            return ("Impact", "T1486", "Data Encrypted for Impact",
                    f"{len(window)} fichiers modifiés en moins de 5 min", ts_seuil)
    return None


def correlate(events):
    """Regroupe les détections par hôte et reconstitue les chaînes d'attaque."""
    by_host = defaultdict(list)
    for ev in events:
        by_host[ev["host"]].append(ev)

    incidents = []
    for host, evs in by_host.items():
        dets = []
        for ev in sorted(evs, key=lambda e: e["time"]):
            hit = detect(ev)
            if hit:
                dets.append((ev["time"], *hit))
        mass = detect_mass_file_change(evs)
        if mass:
            tactic, tid, tname, detail, ts = mass
            dets.append((ts, tactic, tid, tname, detail))
        if not dets:
            continue
        dets.sort(key=lambda x: x[0])

        # critère de chaîne : >= 3 tactiques distinctes, ou Exécution + C2, ou Impact
        tactics = []
        for d in dets:
            if d[1] not in tactics:
                tactics.append(d[1])
        has = lambda t: t in tactics
        if not (len(tactics) >= 3 or (has("Execution") and has("Command and Control")) or has("Impact")):
            continue

        after_hours = any(datetime.fromisoformat(d[0]).hour >= 19 or datetime.fromisoformat(d[0]).hour < 6 for d in dets)
        risk = min(100, 45 + 12 * len(tactics) + (10 if has("Command and Control") else 0)
                   + (12 if has("Impact") else 0) + (6 if after_hours else 0))
        # type d'incident pour le SOAR
        itype = "Ransomware" if has("Impact") else ("Anomalie réseau / C2" if has("Command and Control") else "Compromission probable")

        chaine = [{"heure": d[0][11:19], "tactique": d[1], "technique": f"{d[2]} {d[3]}", "detail": d[4]} for d in dets]
        incidents.append({
            "type": itype, "entity": host, "entity_kind": "poste", "risque": risk,
            "source": "Corrélation SIEM", "activite_hors_heures": after_hours,
            "mitre": sorted({d[2] for d in dets}), "tactiques": tactics, "chaine": chaine,
        })
    return incidents


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="./out_lot2")
    args = ap.parse_args(); os.makedirs(args.out, exist_ok=True)

    events = generate()
    incidents = correlate(events)

    print(f"NEXUS SOC — Corrélation SIEM : {len(events)} événements analysés → {len(incidents)} incident(s) corrélé(s)\n")
    for inc in incidents:
        print(f"┌─ INCIDENT corrélé · {inc['type']} · risque {inc['risque']}/100 · hôte {inc['entity']}")
        print(f"│  Tactiques : {' → '.join(inc['tactiques'])}")
        print(f"│  MITRE : {', '.join(inc['mitre'])}" + ("   (activité hors heures)" if inc["activite_hors_heures"] else ""))
        print("│  Chaîne reconstituée :")
        for s in inc["chaine"][:8]:
            print(f"│    {s['heure']}  [{s['tactique']:<18}] {s['technique']} — {s['detail']}")
        if len(inc["chaine"]) > 8:
            print(f"│    … (+{len(inc['chaine'])-8} étapes)")
        print(f"└─ → transmis au SOAR (type « {inc['type']} »)\n")

    json.dump(incidents, open(f"{args.out}/correlated_incidents.json", "w"), ensure_ascii=False, indent=2)
    print(f"Incident(s) écrit(s) dans {args.out}/correlated_incidents.json")


if __name__ == "__main__":
    main()
