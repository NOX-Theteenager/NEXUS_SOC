#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NEXUS SOC — Générateur de télémétrie brute (pour tester le pipeline du Lot 2)
============================================================================
Produit des événements au FORMAT DE L'AGENT (kind = process / connection /
file_change / system) : du bruit normal sur plusieurs hôtes, plus une CHAÎNE
D'ATTAQUE multi-étapes implantée sur un hôte, pour démontrer la corrélation SIEM.
"""
import random
from datetime import datetime, timedelta

random.seed(42)
TENANT = "11111111-1111-1111-1111-111111111111"

NORMAL_PROCS = ["systemd", "sshd", "nginx", "postgres", "python3", "bash", "cron", "explorer.exe", "chrome"]
NORMAL_PORTS = [80, 443, 53, 22, 3306, 5432]


def _ev(host, kind, data, ts):
    return {"agent_id": f"agent-{host}", "tenant_id": TENANT, "host": host,
            "kind": kind, "time": ts.isoformat(), "data": data}


def normal_host(host, base, n=40):
    """Bruit d'activité normale (heures ouvrables)."""
    out = []
    for i in range(n):
        ts = base + timedelta(minutes=random.randint(0, 480))   # journée de travail
        r = random.random()
        if r < 0.5:
            p = random.choice(NORMAL_PROCS)
            out.append(_ev(host, "process", {"pid": str(random.randint(100, 9999)),
                       "name": p, "exe": f"/usr/bin/{p}", "sha256": "%064x" % random.getrandbits(256)}, ts))
        elif r < 0.85:
            out.append(_ev(host, "connection", {"proto": "tcp",
                       "local": f"10.0.0.{random.randint(2,50)}:{random.randint(40000,60000)}",
                       "remote": f"142.250.{random.randint(0,255)}.{random.randint(1,254)}:{random.choice(NORMAL_PORTS)}",
                       "state": "ESTABLISHED"}, ts))
        else:
            out.append(_ev(host, "file_change", {"path": f"/home/user/doc_{random.randint(1,99)}.txt",
                       "size": random.randint(1000, 50000)}, ts))
    return out


def attack_chain(host, base):
    """Chaîne d'attaque multi-étapes (à reconstituer par le moteur de corrélation)."""
    t = base + timedelta(hours=11, minutes=2)   # début ~22h02 si base à 11h → activité tardive
    chain = [
        # 1. Accès initial : exécutable suspect téléchargé
        _ev(host, "file_change", {"path": "/home/user/Downloads/facture_2026.exe", "size": 245000}, t),
        # 2. Exécution : interpréteur de commandes lancé
        _ev(host, "process", {"pid": "4821", "name": "cmd.exe", "exe": "C:/Windows/System32/cmd.exe", "sha256": ""}, t + timedelta(minutes=1)),
        # 3. Exécution : binaire inconnu depuis un dossier temporaire
        _ev(host, "process", {"pid": "4830", "name": "svch0st", "exe": "/tmp/svch0st", "sha256": ""}, t + timedelta(minutes=1, seconds=20)),
        # 4. Découverte / collecte : accès à un fichier sensible
        _ev(host, "file_change", {"path": "/etc/shadow", "size": 1400}, t + timedelta(minutes=2)),
        # 5. Commande & contrôle : connexion vers un port C2 typique
        _ev(host, "connection", {"proto": "tcp", "local": "10.0.0.7:51000",
                                 "remote": "185.220.101.45:4444", "state": "ESTABLISHED"}, t + timedelta(minutes=3)),
    ]
    # 6. Impact : modification massive de fichiers (rançongiciel)
    for i in range(30):
        chain.append(_ev(host, "file_change",
                     {"path": f"/home/user/docs/fichier_{i}.docx.locked", "size": random.randint(2000, 9000)},
                     t + timedelta(minutes=4, seconds=i)))
    return chain


def generate():
    base = datetime(2026, 5, 20, 9, 0, 0)
    events = []
    for h in ["SRV-WEB-01", "POSTE-RH-03", "POSTE-COMPTA-07"]:
        events += normal_host(h, base)
    events += attack_chain("POSTE-COMPTA-07", base)     # hôte ciblé
    events.sort(key=lambda e: e["time"])
    return events
