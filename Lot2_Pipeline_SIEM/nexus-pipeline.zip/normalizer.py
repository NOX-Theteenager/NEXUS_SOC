#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NEXUS SOC — Normalisation (Lot 2)
=================================
Transforme la télémétrie BRUTE hétérogène de l'agent en :
  1. un SCHÉMA COMMUN normalisé (inspiré d'ECS/OCSF) — ce que fait un SIEM ;
  2. un VECTEUR DE FEATURES comportementales par hôte et par fenêtre temporelle,
     exploitable par un modèle d'anomalie d'hôte (analogue endpoint de l'UEBA).

⚠ Ces features d'hôte sont DISTINCTES des features de flux réseau (Modèle 1, issues d'un
  capteur réseau) et des features d'audit applicatif (Modèle 2, issues de SIGIPES/SYDONIA) :
  chaque source a son extracteur. Le pipeline en héberge plusieurs.

Usage : python normalizer.py [--out ./out_lot2]
"""
import argparse, ipaddress, json, os
from collections import defaultdict
from datetime import datetime

from telemetry_gen import generate

SENSITIVE = ("/etc/shadow", "/etc/passwd", "/etc/sudoers", "finance", "budget", "contribuable")


def is_external(ip):
    try:
        return not ipaddress.ip_address(ip).is_private
    except ValueError:
        return False


def normalize(ev):
    """Mappe un événement brut vers le schéma commun (champs ECS-like)."""
    d = ev.get("data", {})
    base = {"@timestamp": ev["time"], "tenant_id": ev["tenant_id"], "host": ev["host"]}
    k = ev["kind"]
    if k == "process":
        return {**base, "category": "process", "action": "process_start",
                "process": {"name": d.get("name"), "executable": d.get("exe"),
                            "hash_sha256": d.get("sha256", "")}}
    if k == "connection":
        ip = d.get("remote", ":").rsplit(":", 1)[0].strip("[]")
        port = d.get("remote", ":").rsplit(":", 1)[-1]
        return {**base, "category": "network", "action": "connection",
                "destination": {"ip": ip, "port": port}, "network": {"state": d.get("state")}}
    if k == "file_change":
        return {**base, "category": "file", "action": "file_modified",
                "file": {"path": d.get("path"), "size": d.get("size")}}
    return {**base, "category": "host", "action": "heartbeat", "host_info": d}


def aggregate_features(events):
    """Agrège la télémétrie normalisée en un vecteur de features par hôte."""
    by_host = defaultdict(list)
    for ev in events:
        by_host[ev["host"]].append(ev)
    feats = {}
    for host, evs in by_host.items():
        procs = [e for e in evs if e["kind"] == "process"]
        conns = [e for e in evs if e["kind"] == "connection"]
        files = [e for e in evs if e["kind"] == "file_change"]
        ext, remotes = 0, set()
        for c in conns:
            ip = c["data"].get("remote", ":").rsplit(":", 1)[0].strip("[]")
            remotes.add(ip)
            if is_external(ip):
                ext += 1
        after_hours = sum(1 for e in evs
                          if datetime.fromisoformat(e["time"]).hour >= 19 or datetime.fromisoformat(e["time"]).hour < 6)
        sensitive = sum(1 for f in files if any(s in (f["data"].get("path", "")).lower() for s in SENSITIVE))
        feats[host] = {
            "n_process": len(procs),
            "n_unknown_hash": sum(1 for p in procs if not p["data"].get("sha256")),
            "n_tmp_exec": sum(1 for p in procs if (p["data"].get("exe", "") or "").startswith("/tmp")),
            "n_connections": len(conns),
            "n_external_conn": ext,
            "n_unique_remote_ip": len(remotes),
            "n_file_changes": len(files),
            "n_sensitive_access": sensitive,
            "n_after_hours": after_hours,
        }
    return feats


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="./out_lot2")
    args = ap.parse_args(); os.makedirs(args.out, exist_ok=True)

    raw = generate()
    normalized = [normalize(e) for e in raw]
    feats = aggregate_features(raw)

    print(f"NEXUS SOC — Normalisation : {len(raw)} événements bruts → {len(normalized)} événements normalisés")
    print("\nExemple d'événement normalisé (schéma commun) :")
    print(json.dumps(next(n for n in normalized if n["category"] == "network"), ensure_ascii=False, indent=2))
    print("\nVecteur de features comportementales par hôte :")
    for h, f in feats.items():
        print(f"  {h:<16} {f}")

    json.dump(normalized[:50], open(f"{args.out}/normalized_sample.json", "w"), ensure_ascii=False, indent=2)
    json.dump(feats, open(f"{args.out}/host_features.json", "w"), ensure_ascii=False, indent=2)
    print(f"\nÉchantillons écrits dans {args.out}/")


if __name__ == "__main__":
    main()
