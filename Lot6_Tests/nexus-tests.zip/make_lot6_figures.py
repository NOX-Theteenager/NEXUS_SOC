# -*- coding: utf-8 -*-
"""Figures de synthèse du Lot 6 : couverture MITRE testée, MTTD, débit, isolation."""
import json
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

NAVY, BLUE, TEAL, RED, AMBER, GREY = "#0B2545", "#1C6DD0", "#1B998B", "#C1432E", "#B7791F", "#64748B"
LGREY, OK, FAIL = "#EEF3F8", "#16A34A", "#DC2626"
plt.rcParams["font.family"] = "DejaVu Sans"
OUT = "/home/claude/nexus/testing/out_lot6"

# ------------------------------------------------------------------
# 1. Couverture MITRE testée — résultats des tests Atomic-style
# ------------------------------------------------------------------
sim = json.load(open(f"{OUT}/attack_simulation_results.json"))
techs = sim["techniques"]
fig, ax = plt.subplots(figsize=(10.5, 5.2))
y = np.arange(len(techs))[::-1]
for i, t in enumerate(techs):
    if t["ok"]:
        color = OK if t["expected"] else GREY
        marker = "✓"
    else:
        color = AMBER
        marker = "△"
    bar_label = "détectée" if t["detected"] else "non détectée"
    ax.barh(y[i], 1, color=color, alpha=0.85, edgecolor="white")
    ax.text(0.02, y[i], f"{marker}  {t['id']:<10}  {t['name']}",
            va="center", fontsize=9, color="white", weight="bold")
    ax.text(0.98, y[i], bar_label, va="center", ha="right", fontsize=8.5, color="white", style="italic")
ax.set_xlim(0, 1); ax.set_xticks([])
ax.set_yticks([]); ax.set_ylim(-0.5, len(techs) - 0.5)
ax.set_title("NEXUS SOC — Couverture MITRE testée (tests Atomic-style sur le moteur de corrélation)",
             color=NAVY, fontsize=12.5, weight="bold", pad=10)
summary = sim["summary"]
ax.text(0.5, -1.4, f"Couverture des techniques attendues : {summary['coverage']}/{summary['expected_total']} "
        f"·  Vrais négatifs : {summary['correct_negatives']}/3  ·  Scénarios : {summary['scenarios_ok']}/3",
        ha="center", fontsize=9.5, color=NAVY, weight="bold", transform=ax.transData)
fig.subplots_adjust(left=0.02, right=0.98, top=0.92, bottom=0.12)
fig.savefig(f"{OUT}/mitre_coverage_tested.png", dpi=190, bbox_inches="tight", facecolor="white")
plt.close(fig)

# ------------------------------------------------------------------
# 2. MTTD par scénario
# ------------------------------------------------------------------
scen = [s for s in sim["scenarios"] if s.get("detected")]
neg = [s for s in sim["scenarios"] if not s.get("detected")]
fig, ax = plt.subplots(figsize=(8.5, 4))
names = [s["scenario"] for s in scen]
mttd = [s["mttd_sec"] for s in scen]
bars = ax.barh(names, mttd, color=[BLUE, TEAL], edgecolor="white", height=0.55)
for b, s in zip(bars, scen):
    ax.text(b.get_width() + 3, b.get_y() + b.get_height() / 2,
            f"{int(s['mttd_sec'])} s   ·   risque {s['risk']}/100",
            va="center", fontsize=9, color=NAVY, weight="bold")
ax.set_xlim(0, max(mttd) * 1.35)
ax.set_xlabel("MTTD (secondes après le premier événement de la chaîne)", fontsize=9.5)
ax.set_title("NEXUS SOC — MTTD : temps écoulé avant détection (par scénario)",
             color=NAVY, fontsize=12, weight="bold", pad=10)
ax.spines[["top", "right"]].set_visible(False)
if neg:
    ax.text(max(mttd) / 2, -0.95,
            f"+ scénario négatif (trafic légitime) : {neg[0]['scenario']} — aucune alerte levée ✓",
            ha="center", fontsize=9, color=GREY, style="italic")
fig.tight_layout(); fig.savefig(f"{OUT}/mttd_by_scenario.png", dpi=190, bbox_inches="tight", facecolor="white")
plt.close(fig)

# ------------------------------------------------------------------
# 3. Débit du pipeline (test de charge)
# ------------------------------------------------------------------
load = json.load(open(f"{OUT}/load_test_results.json"))
xs = [r["n"] for r in load]
fig, ax = plt.subplots(figsize=(9, 4.5))
ax.plot(xs, [r["norm_eps"] for r in load], marker="o", color=BLUE, lw=2, label="Normalisation")
ax.plot(xs, [r["agg_eps"]  for r in load], marker="s", color=TEAL, lw=2, label="Agrégation features hôte")
ax.plot(xs, [r["corr_eps"] for r in load], marker="^", color=RED, lw=2, label="Corrélation (rules + détection chaîne)")
for r in load:
    ax.annotate(f"{r['corr_eps']:,}", (r["n"], r["corr_eps"]), xytext=(6, -2),
                textcoords="offset points", fontsize=8, color=RED)
ax.set_xscale("log"); ax.set_yscale("log")
ax.set_xlabel("Volume du lot (événements)", fontsize=10)
ax.set_ylabel("Débit (événements / seconde)", fontsize=10)
ax.set_title("NEXUS SOC — Débit du pipeline (mono-cœur)",
             color=NAVY, fontsize=12.5, weight="bold", pad=10)
ax.legend(loc="lower left", fontsize=9)
ax.grid(True, alpha=0.25, ls="--", which="both")
ax.spines[["top", "right"]].set_visible(False)
fig.tight_layout(); fig.savefig(f"{OUT}/load_test_perf.png", dpi=190, bbox_inches="tight", facecolor="white")
plt.close(fig)

# ------------------------------------------------------------------
# 4. Carte de résultat du test d'isolation RLS
# ------------------------------------------------------------------
rls = json.load(open(f"{OUT}/rls_isolation_results.json"))
fig, ax = plt.subplots(figsize=(9.5, 5))
ax.set_xlim(0, 100); ax.set_ylim(0, 100); ax.axis("off")
ax.add_patch(plt.Rectangle((2, 2), 96, 96, fill=False, ec=NAVY, lw=2, transform=ax.transData))
ax.text(50, 92, "Isolation multi-tenant (Row-Level Security)", ha="center",
        fontsize=14, weight="bold", color=NAVY)
status = f"{rls['passed']} / {rls['total']}"
color = OK if rls["passed"] == rls["total"] else FAIL
ax.add_patch(plt.Circle((15, 75), 7, color=color, transform=ax.transData))
ax.text(15, 75, "✓" if rls["passed"] == rls["total"] else "✗",
        ha="center", va="center", fontsize=22, color="white", weight="bold")
ax.text(30, 78, "Assertions vérifiées", fontsize=11, color=NAVY)
ax.text(30, 73, status, fontsize=18, color=color, weight="bold")
y = 60
for c in rls["cases"]:
    ax.text(8, y, "✓" if c["ok"] else "✗", color=OK if c["ok"] else FAIL,
            fontsize=14, weight="bold")
    ax.text(13, y, c["name"], fontsize=10, color=NAVY)
    y -= 8
ax.text(50, 6, "Validation expérimentale sur PostgreSQL 16 avec le rôle applicatif nexus_app (sans super-utilisateur).",
        ha="center", fontsize=9, color=GREY, style="italic")
fig.savefig(f"{OUT}/rls_isolation_result.png", dpi=190, bbox_inches="tight", facecolor="white")
plt.close(fig)

print("Figures générées :",
      "mitre_coverage_tested.png · mttd_by_scenario.png · load_test_perf.png · rls_isolation_result.png")
