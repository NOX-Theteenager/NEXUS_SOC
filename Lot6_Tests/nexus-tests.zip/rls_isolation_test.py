#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NEXUS SOC — Lot 6 : Test d'isolation multi-tenant (Row-Level Security)
======================================================================
Vérifie expérimentalement que la POLITIQUE RLS du schéma multi-tenant fonctionne :
chaque tenant ne voit QUE ses propres alertes, même au niveau de la base.

Procédure :
  1. Création d'une base de test, application du schéma + politique RLS.
  2. Insertion de 3 alertes pour le tenant A et 2 pour le tenant B.
  3. Cinq assertions, exécutées comme une application le ferait (en positionnant
     la variable de session app.current_tenant après authentification).

⚠ NB : par défaut, RLS est contournée pour le super-utilisateur PostgreSQL et pour le
propriétaire de la table. Le test utilise `FORCE ROW LEVEL SECURITY` pour exposer la
politique même au propriétaire — sinon le test passerait sans réellement éprouver l'isolation.
"""
import json
import psycopg2
from psycopg2 import sql


DSN_ADMIN = "host=/var/run/postgresql dbname=postgres user=postgres"
DSN_TEST  = "host=/var/run/postgresql dbname=nexus_rls_test user=postgres"
DSN_APP   = "host=/var/run/postgresql dbname=nexus_rls_test user=nexus_app"

SCHEMA = """
DROP TABLE IF EXISTS alerts CASCADE;
DROP TABLE IF EXISTS tenants CASCADE;

CREATE TABLE tenants (
    id  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    nom TEXT NOT NULL
);

CREATE TABLE alerts (
    id        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL,
    type      TEXT NOT NULL,
    entite    TEXT NOT NULL,
    risque    INT  NOT NULL,
    cree_le   TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE alerts ENABLE ROW LEVEL SECURITY;

CREATE POLICY tenant_isolation_alerts ON alerts
    USING (tenant_id = NULLIF(current_setting('app.current_tenant', true), '')::uuid);

-- Rôle applicatif (non super-utilisateur) : c'est avec ce rôle que le service de
-- scoring se connecte. Les super-utilisateurs contournent toujours la RLS — il est
-- donc essentiel que l'application n'utilise JAMAIS le rôle postgres.
DROP ROLE IF EXISTS nexus_app;
CREATE ROLE nexus_app LOGIN;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO nexus_app;
"""

# UUID des deux tenants (fixés pour rendre le test déterministe)
A = "11111111-1111-1111-1111-111111111111"   # Ministère des Finances
B = "22222222-2222-2222-2222-222222222222"   # Microfinance Exemple


def setup_db():
    """Crée la base de test puis applique le schéma + insère des données pour les deux tenants."""
    conn = psycopg2.connect(DSN_ADMIN); conn.autocommit = True
    with conn.cursor() as c:
        c.execute("DROP DATABASE IF EXISTS nexus_rls_test")
        c.execute("CREATE DATABASE nexus_rls_test")
    conn.close()

    conn = psycopg2.connect(DSN_TEST); conn.autocommit = True
    with conn.cursor() as c:
        c.execute(SCHEMA)
        c.execute("INSERT INTO tenants (id, nom) VALUES (%s, %s), (%s, %s)",
                  (A, "Ministère des Finances", B, "Microfinance Exemple"))
        # En tant que propriétaire, on insère sans déclencher RLS sur INSERT (pas de WITH CHECK)
        rows = [(A, "Ransomware", "POSTE-COMPTA-07", 100),
                (A, "Fraude interne", "agent_DGI_0421", 86),
                (A, "Anomalie réseau / C2", "SRV-WEB-01", 72),
                (B, "Phishing", "POSTE-AGENCE-3", 65),
                (B, "Fraude interne", "agent_MF_017", 78)]
        c.executemany("INSERT INTO alerts (tenant_id, type, entite, risque) VALUES (%s,%s,%s,%s)", rows)
    conn.close()


def run_session_assertions():
    """Joue les requêtes comme l'APPLICATION le ferait : avec un rôle non super-utilisateur,
    en positionnant app.current_tenant après authentification."""
    cases = []
    conn = psycopg2.connect(DSN_APP); conn.autocommit = False

    def query(set_tenant, sql_str, params=None):
        with conn.cursor() as c:
            if set_tenant is not None:
                c.execute("SET app.current_tenant = %s", (set_tenant,))
            else:
                c.execute("RESET app.current_tenant")
            c.execute(sql_str, params or ())
            return c.fetchone()[0]

    # 1. Le tenant A ne voit que ses 3 alertes
    n = query(A, "SELECT COUNT(*) FROM alerts")
    cases.append({"id": 1, "name": "Tenant A : COUNT(alerts) = 3", "got": n, "expect": 3, "ok": n == 3})

    # 2. Le tenant B ne voit que ses 2 alertes
    n = query(B, "SELECT COUNT(*) FROM alerts")
    cases.append({"id": 2, "name": "Tenant B : COUNT(alerts) = 2", "got": n, "expect": 2, "ok": n == 2})

    # 3. Tentative de FUITE : A demande explicitement les alertes de B → doit renvoyer 0
    n = query(A, "SELECT COUNT(*) FROM alerts WHERE tenant_id = %s", (B,))
    cases.append({"id": 3, "name": "Fuite : A interroge tenant_id = B → 0", "got": n, "expect": 0, "ok": n == 0})

    # 4. Sans positionner app.current_tenant : aucune ligne visible
    n = query(None, "SELECT COUNT(*) FROM alerts")
    cases.append({"id": 4, "name": "Session sans tenant : COUNT = 0", "got": n, "expect": 0, "ok": n == 0})

    # 5. Tenant A ne voit que des alertes dont tenant_id = A (somme des tenant_id distincts visibles)
    with conn.cursor() as c:
        c.execute("SET app.current_tenant = %s", (A,))
        c.execute("SELECT DISTINCT tenant_id::text FROM alerts")
        ids = [r[0] for r in c.fetchall()]
    ok = ids == [A]
    cases.append({"id": 5, "name": "Tenant A ne voit QUE des lignes de tenant_id = A",
                  "got": ids, "expect": [A], "ok": ok})

    conn.close()
    return cases


def main():
    import os; os.makedirs("./out_lot6", exist_ok=True)
    print("NEXUS SOC — Lot 6 : test d'isolation multi-tenant (Row-Level Security)\n" + "=" * 70)
    setup_db()
    cases = run_session_assertions()

    print("\n┌─ Assertions")
    for c in cases:
        flag = "✓" if c["ok"] else "✗"
        print(f"│  {flag} #{c['id']} {c['name']:<55} attendu : {c['expect']}  obtenu : {c['got']}")
    passed = sum(c["ok"] for c in cases)
    print(f"└─ Résultat : {passed} / {len(cases)} assertions vérifiées\n")

    json.dump({"passed": passed, "total": len(cases), "cases": cases},
              open("./out_lot6/rls_isolation_results.json", "w"), ensure_ascii=False, indent=2)
    if passed == len(cases):
        print("✅ ISOLATION MULTI-TENANT VÉRIFIÉE — la politique RLS empêche bien tout accès croisé.")
    else:
        print("❌ Au moins une assertion a échoué : la politique RLS est défaillante.")


if __name__ == "__main__":
    main()
