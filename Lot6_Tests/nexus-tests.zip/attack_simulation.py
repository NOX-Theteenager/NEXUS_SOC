#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NEXUS SOC — Lot 6 : Simulation d'attaques (style Atomic Red Team)
=================================================================
Mesure ce que le moteur de corrélation détecte réellement, technique par technique
(couverture MITRE ATT&CK), puis sur des scénarios complets (MTTD).

Approche : pour chaque technique, on génère les ÉVÉNEMENTS DE TÉLÉMÉTRIE qui résulteraient
d'une exécution réelle d'un test Atomic Red Team / Caldera correspondant, et on les passe
au moteur. Cela évite d'avoir à compromettre un poste pour valider la détection — c'est
exactement ce qu'une équipe rouge fait quand elle ne peut pas tirer en production.

Honnêteté : les techniques NON couvertes par les règles SIEM (par ex. T1136 création de
compte, qui relève du Modèle 2 fraude) apparaissent comme « non détectée » — c'est ce qu'on
veut savoir pour la feuille de route.
"""
import json, os, sys
from datetime import datetime, timedelta

# Importer le moteur de corrélation du Lot 2
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "pipeline"))
sys.path.insert(0, "/home/claude/nexus/pipeline")
from correlation_engine import correlate, detect, detect_mass_file_change   # type: ignore

HOST = "POSTE-TEST-01"
TENANT = "11111111-1111-1111-1111-111111111111"
T0 = datetime(2026, 5, 28, 22, 0, 0)


def ev(kind, data, dt):
    return {"agent_id": f"agent-{HOST}", "tenant_id": TENANT, "host": HOST,
            "kind": kind, "time": dt.isoformat(), "data": data}


# --------------------------------------------------------------------------- #
# 1. Tests TECHNIQUE-PAR-TECHNIQUE (Atomic Red Team-style)
# --------------------------------------------------------------------------- #
ATOMIC_TESTS = [
    {"id": "T1059.001", "name": "PowerShell",
     "events": [ev("process", {"name": "powershell.exe", "exe": "C:/Windows/.../powershell.exe", "sha256": ""}, T0)],
     "expected": True},
    {"id": "T1059.003", "name": "Windows Command Shell",
     "events": [ev("process", {"name": "cmd.exe", "exe": "C:/Windows/System32/cmd.exe", "sha256": ""}, T0)],
     "expected": True},
    {"id": "T1059.004", "name": "Unix Shell (binaire dans /tmp)",
     "events": [ev("process", {"name": "x", "exe": "/tmp/payload", "sha256": ""}, T0)],
     "expected": True},
    {"id": "T1204.002", "name": "User Execution — fichier malveillant",
     "events": [ev("file_change", {"path": "/home/user/Downloads/facture.exe", "size": 200000}, T0)],
     "expected": True},
    {"id": "T1005",     "name": "Data from Local System (fichier sensible)",
     "events": [ev("file_change", {"path": "/etc/shadow", "size": 1400}, T0)],
     "expected": True},
    {"id": "T1071.001", "name": "Application Layer Protocol (C2)",
     "events": [ev("connection", {"proto": "tcp", "remote": "185.220.101.45:4444", "state": "ESTABLISHED"}, T0)],
     "expected": True},
    {"id": "T1486",     "name": "Data Encrypted for Impact (rançongiciel)",
     "events": [ev("file_change", {"path": f"/home/user/docs/f{i}.locked", "size": 5000},
                   T0 + timedelta(seconds=i)) for i in range(25)],
     "expected": True, "mass": True},
    # --- Techniques NON couvertes par les règles SIEM actuelles (gaps à documenter) ---
    {"id": "T1083",     "name": "File and Directory Discovery",
     "events": [ev("file_change", {"path": "/home/user/listing.txt", "size": 200}, T0)],
     "expected": False, "note": "Discovery — non couvert (peu de signal exploitable côté endpoint)"},
    {"id": "T1136",     "name": "Create Account",
     "events": [ev("process", {"name": "useradd", "exe": "/usr/sbin/useradd", "sha256": "abc"}, T0)],
     "expected": False, "note": "Détecté côté UEBA (Modèle 2) sur les logs SIGIPES, pas par les règles SIEM"},
    {"id": "T1027",     "name": "Obfuscated Files",
     "events": [ev("process", {"name": "obfusc.ps1", "exe": "C:/temp/obfusc.ps1", "sha256": ""}, T0)],
     "expected": False, "note": "Obfuscation — couverture à étendre (règles YARA / contenu)"},
]


def test_techniques():
    print("┌─ Tests TECHNIQUE-PAR-TECHNIQUE (style Atomic Red Team)")
    results = []
    for t in ATOMIC_TESTS:
        if t.get("mass"):
            hit = detect_mass_file_change(t["events"])
        else:
            hit = next((detect(e) for e in t["events"] if detect(e)), None)
        detected = hit is not None
        ok = (detected == t["expected"])
        results.append({**{k: t[k] for k in ("id", "name", "expected")},
                        "detected": detected, "ok": ok, "note": t.get("note", "")})
        flag = "✓" if ok else "✗"
        attendu = "détecter" if t["expected"] else "ignorer"
        observe = "détectée" if detected else "ignorée"
        print(f"│  {flag} {t['id']:<10} {t['name']:<48} attendu : {attendu:<8} → {observe}")
    return results


# --------------------------------------------------------------------------- #
# 2. SCÉNARIOS multi-étapes — mesure du MTTD (Mean Time To Detect)
#    On rejoue les événements dans l'ordre chronologique et on regarde à quel
#    moment le moteur LÈVE l'incident (= quand les critères de chaîne sont remplis).
# --------------------------------------------------------------------------- #
def scenario_ransomware():
    t = T0
    chain = [
        ev("file_change", {"path": "/home/user/Downloads/facture_2026.exe", "size": 245000}, t),
        ev("process", {"name": "cmd.exe", "exe": "C:/Windows/System32/cmd.exe", "sha256": ""}, t + timedelta(seconds=60)),
        ev("file_change", {"path": "/etc/shadow", "size": 1400}, t + timedelta(seconds=120)),
        ev("connection", {"proto": "tcp", "remote": "185.220.101.45:4444", "state": "ESTABLISHED"}, t + timedelta(seconds=180)),
    ]
    chain += [ev("file_change", {"path": f"/home/user/docs/fichier_{i}.locked", "size": 5000},
                 t + timedelta(seconds=240 + i)) for i in range(25)]
    return ("Ransomware (chaîne complète)", chain, True)

def scenario_exfiltration():
    t = T0
    chain = [
        ev("process", {"name": "powershell.exe", "exe": "C:/...", "sha256": ""}, t),
        ev("file_change", {"path": "/data/finance/budget_2026.xlsx", "size": 50000}, t + timedelta(seconds=30)),
        ev("file_change", {"path": "/data/finance/contribuables.csv", "size": 200000}, t + timedelta(seconds=60)),
        ev("connection", {"proto": "tcp", "remote": "203.0.113.42:9001", "state": "ESTABLISHED"}, t + timedelta(seconds=90)),
    ]
    return ("Exfiltration (3 tactiques)", chain, True)

def scenario_negative():
    """Trafic professionnel normal : ne DOIT PAS lever d'incident."""
    t = T0
    chain = [
        ev("process", {"name": "powershell.exe", "exe": "C:/...", "sha256": ""}, t),     # Execution
        ev("connection", {"proto": "tcp", "remote": "142.250.10.5:443", "state": "ESTABLISHED"}, t + timedelta(seconds=30)),
        ev("connection", {"proto": "tcp", "remote": "142.250.10.6:443", "state": "ESTABLISHED"}, t + timedelta(seconds=60)),
        ev("file_change", {"path": "/home/user/rapport.docx", "size": 30000}, t + timedelta(seconds=120)),
    ]
    return ("Trafic légitime (négatif)", chain, False)


def measure_mttd(name, events, must_detect):
    """Mesure le MTTD : on alimente le moteur progressivement et on note l'instant
    où il lève l'incident (= moment où les critères de chaîne sont remplis)."""
    t0 = datetime.fromisoformat(events[0]["time"])
    cum = []
    for e in events:
        cum.append(e)
        incs = correlate(cum)
        if incs:
            mttd = (datetime.fromisoformat(e["time"]) - t0).total_seconds()
            return {"scenario": name, "mttd_sec": mttd, "detected": True,
                    "ok": must_detect, "deciding_event": e["time"],
                    "tactics": incs[0]["tactiques"], "risk": incs[0]["risque"]}
    return {"scenario": name, "mttd_sec": None, "detected": False, "ok": (not must_detect)}


def test_scenarios():
    print("\n┌─ SCÉNARIOS multi-étapes — mesure du MTTD")
    out = []
    for build in (scenario_ransomware, scenario_exfiltration, scenario_negative):
        r = measure_mttd(*build())
        out.append(r)
        flag = "✓" if r["ok"] else "✗"
        if r["detected"]:
            print(f"│  {flag} {r['scenario']:<32} MTTD = {r['mttd_sec']:>5.0f} s  "
                  f"(risque {r['risk']}/100, tactiques : {' → '.join(r['tactics'])})")
        else:
            print(f"│  {flag} {r['scenario']:<32} non détecté (attendu : "
                  f"{'détection' if not r['ok'] else 'aucune'})")
    return out


# --------------------------------------------------------------------------- #
def main():
    out_dir = "./out_lot6"; os.makedirs(out_dir, exist_ok=True)
    print("NEXUS SOC — Lot 6 : simulation d'attaques\n" + "=" * 46)
    tech = test_techniques()
    scen = test_scenarios()

    coverage = sum(1 for t in tech if t["expected"] and t["detected"])
    expected_total = sum(1 for t in tech if t["expected"])
    correct_negatives = sum(1 for t in tech if not t["expected"] and not t["detected"])
    print(f"\n┌─ SYNTHÈSE")
    print(f"│  Couverture des techniques attendues : {coverage}/{expected_total} "
          f"({coverage*100//expected_total}%)")
    print(f"│  Vrais négatifs (techniques hors scope correctement ignorées) : "
          f"{correct_negatives}/{sum(1 for t in tech if not t['expected'])}")
    pass_scen = sum(1 for s in scen if s["ok"])
    print(f"│  Scénarios réussis : {pass_scen}/{len(scen)}")
    print("└─")

    json.dump({"techniques": tech, "scenarios": scen,
               "summary": {"coverage": coverage, "expected_total": expected_total,
                           "correct_negatives": correct_negatives, "scenarios_ok": pass_scen}},
              open(f"{out_dir}/attack_simulation_results.json", "w"),
              ensure_ascii=False, indent=2)
    print(f"\n  Résultats : {out_dir}/attack_simulation_results.json")


if __name__ == "__main__":
    main()
