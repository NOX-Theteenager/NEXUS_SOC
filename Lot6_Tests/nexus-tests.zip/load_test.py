#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NEXUS SOC — Lot 6 : Test de charge du pipeline
==============================================
Mesure le DÉBIT (événements/seconde) et la LATENCE (μs/événement) du normaliseur et du
moteur de corrélation à différents volumes : 1k, 5k, 25k, 100k événements. Ces chiffres
sont mesurés ici sur un seul cœur ; en production, le pipeline est parallélisable par
hôte/tenant (consumers Kafka indépendants).
"""
import json, os, random, sys, time
from datetime import datetime, timedelta

sys.path.insert(0, "/home/claude/nexus/pipeline")
from correlation_engine import correlate                     # type: ignore
from normalizer import normalize, aggregate_features          # type: ignore

random.seed(42)


def gen_stream(n, n_hosts=20):
    """Génère un flux d'événements représentatif : surtout normaux + quelques bizarreries."""
    base = datetime(2026, 5, 28, 9, 0, 0)
    out = []
    for i in range(n):
        host = f"HOST-{random.randint(1, n_hosts):02d}"
        ts = (base + timedelta(seconds=i * 2)).isoformat()
        r = random.random()
        if r < 0.55:
            d = {"name": random.choice(["systemd", "sshd", "python3", "nginx", "bash"]),
                 "exe": "/usr/bin/x", "sha256": "%064x" % random.getrandbits(256)}
            k = "process"
        elif r < 0.85:
            d = {"proto": "tcp", "local": f"10.0.0.{random.randint(2, 50)}:43210",
                 "remote": f"142.250.{random.randint(0, 255)}.{random.randint(1, 254)}:{random.choice([80, 443, 53])}",
                 "state": "ESTABLISHED"}
            k = "connection"
        else:
            d = {"path": f"/home/user/file_{random.randint(1, 999)}.txt", "size": random.randint(100, 5000)}
            k = "file_change"
        out.append({"agent_id": f"agent-{host}", "tenant_id": "T1",
                    "host": host, "kind": k, "time": ts, "data": d})
    return out


def bench(events, label):
    """Mesure normaliseur + corrélateur sur la liste complète, plus latence par chunks."""
    n = len(events)
    print(f"\n┌─ {label} — {n:,} événements")

    # 1) Normaliseur (un par un)
    t0 = time.perf_counter()
    _ = [normalize(e) for e in events]
    t_norm = time.perf_counter() - t0
    print(f"│  Normalisation   : {t_norm*1000:>8.1f} ms   "
          f"→ {n/t_norm:>10,.0f} ev/s   ({t_norm/n*1e6:>5.1f} μs/ev)")

    # 2) Agrégation de features par hôte
    t0 = time.perf_counter()
    _ = aggregate_features(events)
    t_agg = time.perf_counter() - t0
    print(f"│  Agrégation host : {t_agg*1000:>8.1f} ms   "
          f"→ {n/t_agg:>10,.0f} ev/s")

    # 3) Corrélation
    t0 = time.perf_counter()
    _ = correlate(events)
    t_corr = time.perf_counter() - t0
    print(f"│  Corrélation     : {t_corr*1000:>8.1f} ms   "
          f"→ {n/t_corr:>10,.0f} ev/s   ({t_corr/n*1e6:>5.1f} μs/ev)")

    # 4) Latence par chunks (simule un traitement en flux)
    chunk = max(1, n // 50)
    lat = []
    for i in range(0, n, chunk):
        t0 = time.perf_counter()
        _ = [normalize(e) for e in events[i:i + chunk]]
        lat.append((time.perf_counter() - t0) * 1000 / chunk * 1000)   # μs / ev
    lat.sort()
    p50 = lat[len(lat) // 2]; p95 = lat[int(len(lat) * 0.95)]; p99 = lat[int(len(lat) * 0.99)]
    print(f"│  Latence norm    : p50 = {p50:>5.1f} μs · p95 = {p95:>5.1f} μs · p99 = {p99:>5.1f} μs")
    return {"n": n, "label": label,
            "norm_ms": round(t_norm * 1000, 2), "norm_eps": int(n / t_norm),
            "agg_ms": round(t_agg * 1000, 2), "agg_eps": int(n / t_agg),
            "corr_ms": round(t_corr * 1000, 2), "corr_eps": int(n / t_corr),
            "lat_p50_us": round(p50, 1), "lat_p95_us": round(p95, 1), "lat_p99_us": round(p99, 1)}


def main():
    out_dir = "./out_lot6"; os.makedirs(out_dir, exist_ok=True)
    print("NEXUS SOC — Lot 6 : test de charge\n" + "=" * 38)
    results = []
    for n in (1_000, 5_000, 25_000, 100_000):
        results.append(bench(gen_stream(n), f"Charge n={n}"))

    # Synthèse — débit utile pour dimensionner
    print("\n┌─ SYNTHÈSE (débit du moteur de corrélation)")
    print("│  Volume        Norm (ev/s)   Corr (ev/s)   p95 latence")
    for r in results:
        print(f"│  {r['n']:>7,}    {r['norm_eps']:>11,}   {r['corr_eps']:>11,}   {r['lat_p95_us']:>5.1f} μs")
    print("└─")
    json.dump(results, open(f"{out_dir}/load_test_results.json", "w"), indent=2)
    print(f"\n  Résultats : {out_dir}/load_test_results.json")


if __name__ == "__main__":
    main()
